# root-of-life
FlipperZero puzzle game made for GlobalGameJam'23

TBD
