#pragma once
#include "cligui_main_i.h"

extern void text_input_result_callback(void* ctx);
extern void text_input_input_handler(CliguiApp*, InputEvent*);