// ####..
// ..##..
// ..##..
// ..##..
// ######

#include "images.h"

const image_t img_3x5_1 = {3, 5, false, 2, 0, {0xC9, 0x2E}};
