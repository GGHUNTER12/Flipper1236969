# flipper-zero-hex_editor

inspired by QtRoS/flipper-zero-hex-viewer

Read any file line by line, and by Ok allow change char. Useful for NFC file "Edit Dump" feature with out smartphone.

# NB
* interface under construction
* not tested on UTF-8
* not inspected on memory leaks

