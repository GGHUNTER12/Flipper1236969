ADD_SCENE(wifi_marauder, start, Start)
ADD_SCENE(wifi_marauder, console_output, ConsoleOutput)
ADD_SCENE(wifi_marauder, text_input, TextInput)
