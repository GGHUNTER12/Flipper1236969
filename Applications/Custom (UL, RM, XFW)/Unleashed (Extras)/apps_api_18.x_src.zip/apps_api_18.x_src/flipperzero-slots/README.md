
# Slots for Flipper Zero :)
![Screen1](screen1.png "Title")
![Screen2](screen2.png "Title")

I am not a C programmer, so any suggestions are welcome!