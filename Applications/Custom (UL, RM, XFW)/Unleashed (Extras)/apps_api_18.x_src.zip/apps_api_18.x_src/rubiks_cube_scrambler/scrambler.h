void scrambleReplace();
void genScramble();
char* printData();
