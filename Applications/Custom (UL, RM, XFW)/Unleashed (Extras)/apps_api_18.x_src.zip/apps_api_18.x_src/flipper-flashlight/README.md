# Flashlight Plugin for Flipper Zero

Simple Flashlight special for @Svaarich by @xMasterX

Enables 3.3v on pin 7/C3 and leaves it on when you exit app

**Connect LED to (+ -> 7/C3) | (GND -> GND)**
