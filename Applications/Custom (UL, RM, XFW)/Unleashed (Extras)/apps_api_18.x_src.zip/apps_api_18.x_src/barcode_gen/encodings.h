#pragma once

extern const char EAN_13_STRUCTURE_CODES[10][6];
extern const char UPC_EAN_L_CODES[10][8];
extern const char EAN_G_CODES[10][8];
extern const char UPC_EAN_R_CODES[10][8];