# flipperzero-ocarina
A basic Ocarina (of Time) for the Flipper Zero.

Controls are the same as the N64 version of the Ocarina of Time, the Ok button takes the place of the A button
