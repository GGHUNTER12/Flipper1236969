# flipper_passgen
This is a simple Password Generator plugin (**fap**) for the [Flipper Zero](https://www.flipperzero.one).

![preview](images/preview.png)