# Changelog

## 0.4
- Show active/inactive state in primary font (bold)

## 0.3
- Add a delay between key-presses (with left/right buttons)

## 0.2
- Update icon

## 0.1
- Initial release of the USB HID Autofire application
