ADD_SCENE(mifare_fuzzer, start, Start)
ADD_SCENE(mifare_fuzzer, attack, Attack)
ADD_SCENE(mifare_fuzzer, emulator, Emulator)