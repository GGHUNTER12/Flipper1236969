#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct BarCodeApp BarCodeApp;

#ifdef __cplusplus
}
#endif
