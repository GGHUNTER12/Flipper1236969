#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct WifiMarauderApp WifiMarauderApp;

#ifdef __cplusplus
}
#endif
