ADD_SCENE(uart_terminal, start, Start)
ADD_SCENE(uart_terminal, console_output, ConsoleOutput)
ADD_SCENE(uart_terminal, text_input, UART_TextInput)
