# flipperzero_GPIO_read

Plugin to read the GPIOs on the Flipper Zero.
