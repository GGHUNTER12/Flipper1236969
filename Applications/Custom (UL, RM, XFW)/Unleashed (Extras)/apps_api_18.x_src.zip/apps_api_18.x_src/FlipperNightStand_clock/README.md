# FlipperNightStand  

Fork of the standard clock app, for use as a bedside clock at night  

-Date and AM/PM have their places swapped  
-Backlight stays on constantly  
-Control brightness with up/down  
-Notification LED is turned off by default  
-At 0 brightness, press down to toggle the LED between off and dim red
