#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct UART_TerminalApp UART_TerminalApp;

#ifdef __cplusplus
}
#endif
